animal(lion).
animal(tiger).
animal(cow).
carnivore(lion).
carnivore(tiger).